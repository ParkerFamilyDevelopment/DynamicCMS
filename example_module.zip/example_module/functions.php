<?php
//This file can be used to create functions that can be accessed only by your module, to create a function that can be used globally, place it in the custom_functions.php file located in the includes folder.
?>