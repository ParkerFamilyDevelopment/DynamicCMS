<?php
echo "<h3 class='display-9'>Example Module</h3>";
echo '<p class="lead">This is an example action for the DynamicCMS module "example_module".</p>';
echo 'It can be accessed by linking to <a href="/?mod=example_module&act=action">/?mod=example_module&act=action</a>';
?>