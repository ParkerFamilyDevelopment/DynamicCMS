<?php
echo "<h3 class='display-9'>Example Module</h3>";
echo "<p class='lead'>This is an example module for DynamicCMS.</p>";
echo 'It can be accessed by linking to <a href="/?mod=example_module">/?mod=example_module</a>';
?>