<?php
//This file can be used in the future to perform actions such as database alterations upon uninstallation.
echo "If you can see this the uninstaller function is working.";
?>