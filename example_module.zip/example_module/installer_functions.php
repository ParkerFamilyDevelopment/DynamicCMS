<?php
//This file can be used in the future to perform actions such as database additions/alterations upon installation.
echo "If you can see this the installer functions is working.";
?>